const invitationCategoryData = ["Glass Box", "Wooden Box", "Misc Invitation"];
const PriceRangeData = ['50-150', '150-300', '300-500', '500 & Above'];
const sweetsData = ["Bengali", "Kesariya", "Pethe"];
const decorartionData = ["Marriage", "BirthDay", "Mehndi", "Party"];
const planningCategoryData = ["Marriage", "Mehndi", "Birthday", "Room Decor"];

export { invitationCategoryData, PriceRangeData, sweetsData, decorartionData, planningCategoryData };